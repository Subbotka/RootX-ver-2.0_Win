# JavaScript ROOT

JavaScript ROOT provides interactive ROOT-like graphics in the web browsers.
Data can be read and displayed from binary and JSON ROOT files.
JSROOT implements user interface for THttpServer class.

<a href="https://root.cern/js/latest/?nobrowser&file=https://root.cern/js/files/hsimple.root&item=ntuple;1&opt=px:py::pz%3E4"><img src="https://root.cern/js/files/img/ttree.png" align="left" hspace="10" vspace="6" alt="TTree::Draw()" title="2-dimensional TTree::Draw with cut options"></a>
<a href="https://root.cern/js/latest/?nobrowser&file=https://root.cern/js/files/histpainter6.root&item=draw_hstack;1"><img src="https://root.cern/js/files/img/thstack.png" align="left" hspace="10" vspace="6" alt="THStack" title="Several varians of THStack drawing"></a>
<a href="https://root.cern/js/latest/?nobrowser&json=https://root.cern/js/files/geom/simple_alice.json.gz&file=https://root.cern/js/files/geom/tracks_hits.root&item=simple_alice.json.gz+tracks_hits.root/tracks;1+tracks_hits.root/hits;1"><img src="https://root.cern/js/files/img/geo_tracks.png" align="left" hspace="10" vspace="6" alt="Geometry" title="Drawing of TGeo model superimposed with tracks and hits"></a>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>


## Links

Project web pages:

[https://root.cern/js/](https://root.cern/js/)

[https://jsroot.gsi.de](https://jsroot.gsi.de/)


## Examples

[JSROOT examples](https://root.cern/js/latest/examples.htm)

[JSROOT API examples](https://root.cern/js/latest/api.htm)

